import React from 'react';
import { Book } from 'lucide-react';
import QuizCard from './components/QuizCard';
import './index.css';

function App() {
  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4">
      <div className="absolute top-6 left-6 flex items-center text-[#666666]">
        <Book className="w-5 h-5 mr-2" />
        <span className="text-sm font-medium">РусскийКвиз</span>
      </div>
      <QuizCard />
    </div>
  );
}

export default App;