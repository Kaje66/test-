import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface AnswerButtonProps {
  text: string;
  onClick: () => void;
}

const AnswerButton: React.FC<AnswerButtonProps> = ({ text, onClick }) => {
  const [isHovered, setIsHovered] = useState(false);
  
  return (
    <motion.button
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`py-4 px-6 rounded-full bg-gradient-to-r from-cyan-300 to-cyan-200 text-gray-800 font-medium text-center transition-shadow duration-300 ${
        isHovered ? 'shadow-lg' : 'shadow-md'
      }`}
    >
      {text}
    </motion.button>
  );
};

export default AnswerButton;