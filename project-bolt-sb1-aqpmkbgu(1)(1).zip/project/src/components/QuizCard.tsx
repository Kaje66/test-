import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { quizData } from '../data/quizData';

const QuizCard: React.FC = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);

  const currentQuestion = quizData[currentQuestionIndex];
  const showResults = currentQuestionIndex === quizData.length - 1 && selected !== null;
  const percentage = Math.round((score / quizData.length) * 100);

  const handleAnswer = (index: number) => {
    const correct = index === currentQuestion.correct;
    setSelected(index);
    setIsCorrect(correct);
    if (correct) setScore(prev => prev + 1);
    
    setTimeout(() => {
      if (currentQuestionIndex < quizData.length - 1) {
        setCurrentQuestionIndex(prev => prev + 1);
        setSelected(null);
        setIsCorrect(null);
      }
    }, 1500);
  };

  const resetQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelected(null);
    setIsCorrect(null);
    setScore(0);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-gradient-to-b from-[#E6F0FA] to-[#E8E3F9] w-full max-w-3xl rounded-[30px] shadow-lg overflow-hidden relative"
    >
      <div 
        className="absolute inset-0 opacity-30 pointer-events-none"
        style={{
          backgroundImage: 'url("https://i.imgur.com/vqSXTDd.png")',
          backgroundSize: '60%',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      />
      <div className="p-8 md:p-10 relative z-10">
        <div className="absolute top-4 right-4 bg-white/30 backdrop-blur-sm px-4 py-2 rounded-full">
          <span className="text-[#2A2A2A] font-medium">{score}/{quizData.length} AC</span>
        </div>
        
        {!showResults ? (
          <>
            <h1 className="text-3xl md:text-4xl font-bold text-center mb-6 text-[#2A2A2A]">
              {currentQuestion.title.replace('# ', '')}
            </h1>
            
            <h2 className="text-xl md:text-2xl text-center mb-12 text-[#666666] font-normal">
              {currentQuestion.question}
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 mx-auto max-w-2xl relative z-10">
              {currentQuestion.answers.map((answer, index) => (
                <motion.button
                  key={index}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleAnswer(index)}
                  disabled={selected !== null}
                  className={`
                    py-4 px-6 rounded-[20px] text-[#333333] font-medium text-center
                    transition-all duration-300 bg-gradient-to-r from-[#A3E7F5] to-[#7FD6EA]
                    shadow-md hover:shadow-lg disabled:cursor-not-allowed
                    ${selected === index && isCorrect ? 'bg-green-400 from-green-400 to-green-500' : ''}
                    ${selected === index && !isCorrect ? 'bg-red-400 from-red-400 to-red-500' : ''}
                  `}
                >
                  {answer}
                </motion.button>
              ))}
            </div>
          </>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-8"
          >
            <h2 className="text-3xl font-bold mb-6 text-[#2A2A2A]">Результат теста</h2>
            <p className="text-xl mb-4 text-[#666666]">
              Вы правильно ответили на {score} из {quizData.length} вопросов
            </p>
            <p className="text-3xl font-bold text-[#2A2A2A] mb-8">{percentage}%</p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={resetQuiz}
              className="px-8 py-3 bg-gradient-to-r from-[#A3E7F5] to-[#7FD6EA] rounded-[20px] 
                        text-[#333333] font-medium shadow-md hover:shadow-lg transition-all duration-300"
            >
              Пройти снова
            </motion.button>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};

export default QuizCard;